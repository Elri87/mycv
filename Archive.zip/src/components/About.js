import React, { Component } from "react";

export default class About extends Component {
    render() {
        return (
            <div>
                <div className='card'>
                    <div className='card-content'>
                        <h6 className='mt-bottom'>
                            <strong>ABOUT ME</strong>
                        </h6>
                        <p className='grey-text'>
                            Here is where the about me will go in a paragraph
                        </p>
                    </div>
                    <div className='card-action'>
                        <h6>
                            <strong>PERSONAL INFO</strong>
                        </h6>
                        <div className='row mt'>
                            <div className='col s12 m6 l6 xl6'>
                                <p><strong>Adress:</strong>7 Waterford Close, Gordon's Bay
                                </p>
                                <p><strong>Email:</strong>87elrivdm@gmail.com
                                </p>
                                <p><strong>Phone:</strong>+27 822 53 6345
                                </p>
                            </div>
                            <div className='s12 m6 l6 xl6'>
                            <p><strong>Main Language</strong>Afrikaans
                                </p>
                                <p><strong>Second Language</strong>English
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}